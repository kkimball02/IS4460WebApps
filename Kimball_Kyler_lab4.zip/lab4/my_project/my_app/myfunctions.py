def fix_names_list(names: list):
    return_list = [x.title() for x in names]
    return return_list